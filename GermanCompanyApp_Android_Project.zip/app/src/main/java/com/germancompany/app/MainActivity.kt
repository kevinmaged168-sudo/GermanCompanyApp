package com.germancompany.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues

class InventoryDb(context: android.content.Context) :
    SQLiteOpenHelper(context, "german_company.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "part_number TEXT NOT NULL," +
                "brand TEXT NOT NULL," +
                "quantity INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE UNIQUE INDEX idx_item_part_brand ON items(part_number, brand)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addItem(name: String, part: String, brand: String, qty: Int): Boolean {
        val values = ContentValues().apply {
            put("name", name); put("part_number", part); put("brand", brand); put("quantity", qty)
        }
        return writableDatabase.insert("items", null, values) != -1L
    }
    fun allItems(): List<String> {
        val result = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT name, part_number, brand, quantity FROM items ORDER BY name", null
        ).use { c ->
            while (c.moveToNext()) {
                result.add("${c.getString(0)} | ${c.getString(1)} | ${c.getString(2)} | الكمية: ${c.getInt(3)}")
            }
        }
        return result
    }
}

class MainActivity : Activity() {
    private lateinit var db: InventoryDb
    private lateinit var list: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = InventoryDb(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        fun field(hint: String) = EditText(this).apply {
            this.hint = hint
            textSize = 16f
            singleLine = true
        }

        val title = TextView(this).apply {
            text = "إدارة مخزون الشركة الألمانية"
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        val name = field("اسم الصنف")
        val part = field("رقم القطعة")
        val brand = field("الماركة: مرسيدس / سكودا / أوبل")
        val qty = field("الكمية")
        qty.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        val add = Button(this).apply { text = "إضافة صنف" }
        val status = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 8) }
        val heading = TextView(this).apply {
            text = "الأصناف المسجلة"
            textSize = 18f
            setPadding(0, 16, 0, 8)
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }

        root.addView(title)
        root.addView(name)
        root.addView(part)
        root.addView(brand)
        root.addView(qty)
        root.addView(add)
        root.addView(status)
        root.addView(heading)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        add.setOnClickListener {
            val n = name.text.toString().trim()
            val p = part.text.toString().trim()
            val b = brand.text.toString().trim()
            val q = qty.text.toString().toIntOrNull()
            if (n.isEmpty() || p.isEmpty() || b.isEmpty() || q == null || q < 0) {
                status.text = "اكتب اسم الصنف ورقم القطعة والماركة والكمية بشكل صحيح."
            } else if (db.addItem(n, p, b, q)) {
                status.text = "تمت إضافة الصنف."
                name.text.clear(); part.text.clear(); brand.text.clear(); qty.text.clear()
                refresh()
            } else {
                status.text = "رقم القطعة مسجل بالفعل لنفس الماركة."
            }
        }
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val items = db.allItems()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply { text = "لا توجد أصناف حتى الآن." })
        } else {
            items.forEach { item ->
                list.addView(TextView(this).apply {
                    text = item
                    textSize = 15f
                    setPadding(4, 10, 4, 10)
                })
            }
        }
    }
}
